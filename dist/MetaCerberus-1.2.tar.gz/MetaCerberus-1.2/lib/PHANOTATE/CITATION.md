# Citing Phanotate

If you use phanotate, please cite this paper:

```text
Katelyn McNair, Carol Zhou, Elizabeth A Dinsdale, Brian Souza, Robert A Edwards, PHANOTATE: a novel approach to gene identification in phage genomes, Bioinformatics, Volume 35, Issue 22, 15 November 2019, Pages 4537–4542, https://doi.org/10.1093/bioinformatics/btz265
```
