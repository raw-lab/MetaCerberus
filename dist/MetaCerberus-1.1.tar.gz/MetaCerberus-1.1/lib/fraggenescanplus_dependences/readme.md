# Files required for Fraggenescan-plus 

- Error profile files
