# Dependancy files for trimming and other tools

- Porecrop
- Filtering contaminants (phiX - Illumina, Lambda - PacBio) 
